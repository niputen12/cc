<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class addfriend extends Model
{
     protected $table = 'friends';
	public $timestamps = false;
}
